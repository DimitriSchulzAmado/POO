import openpyxl
from openpyxl import Workbook
import pathlib
import pandas as pd  # usar pandas para fazer o dataframe (pandas tem foco em analise de dados)
# manipulação de arquivo em txt com python

file_path = pathlib.Path("Clientes.xlsx")

if file_path.exists():
    pass
else:
    # create a new file_path
    file_path = Workbook()
    sheet = file_path.active
    sheet['A1'] = "Razão Social"
    sheet['B1'] = "Nome Fantasia"
    sheet['C1'] = "CNPJ"
    sheet['D1'] = "Endereço"
    sheet['E1'] = "Contato"
    sheet['F1'] = "E-mail"
    sheet['G1'] = "WhatsApp"
    sheet['H1'] = "Telefone"

    file_path.save("Clientes.xlsx")

social_reason = input("Razão Social: ")
fantasy_name = input("Nome Fantasia: ")
id_company = int(input("CNPJ: "))
address = input("Endereço: ")
contact = input("Contato: ")
email = input("E-mail: ")
whatsapp = int(input("WhatsApp: "))
phone = int(input("Telefone: "))

try:
    file_path = openpyxl.load_workbook("Clientes.xlsx")
    sheet = file_path.active
except FileNotFoundError:
    file_path = openpyxl.Workbook()
    sheet = file_path.active
    sheet.cell(column=1, row=sheet.max_row+1, value=social_reason)
    sheet.cell(column=2, row=sheet.max_row+1, value=fantasy_name)
    sheet.cell(column=3, row=sheet.max_row+1, value=id_company)
    sheet.cell(column=4, row=sheet.max_row+1, value=address)
    sheet.cell(column=5, row=sheet.max_row+1, value=contact)
    sheet.cell(column=6, row=sheet.max_row+1, value=email)
    sheet.cell(column=7, row=sheet.max_row+1, value=whatsapp)
    sheet.cell(column=8, row=sheet.max_row+1, value=phone)

file_path.save(r"Cliente.xlsx")
print("Dados salvos com sucesso!")
file_path.close()
