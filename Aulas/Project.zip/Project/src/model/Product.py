from src.model.Company import Company


class Product:

    def __int__(self, name, price, brand):
        self.name = name
        self.price = price
        self.brand = brand
