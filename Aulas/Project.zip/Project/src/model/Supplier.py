class Supplier:
    def sell(self):
        pass
