import customtkinter as ctk
from customtkinter import *


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.windows_config()
        self.theme_config()
        self.frontend()

    def windows_config(self):
        self.title('Sistema novo')
        self.geometry('800x650')
        self._set_appearance_mode('System')
        self.minsize(width=800, height=650)

    def theme_config(self):
        self.switch_var = ctk.StringVar(value='off')
        def set_theme():
            if self.switch_var.get() == 'dark':
                ctk.set_appearance_mode('Dark')
            elif self.switch_var.get() == 'light':
                ctk.set_appearance_mode('Light')
            else:
                ctk.set_appearance_mode("System")

        self.switch = ctk.CTkSwitch(self, text='', variable=self.switch_var, onvalue='dark',
                                    offvalue='light', command=set_theme)
        self.switch.place(x=25, y=20)

    def frontend(self):
        self.tt = ctk.CTkLabel(self, text='System Test', font=('arial bold', 30))
        self.tt.pack(pady=20)

        self.tabview = ctk.CTkTabview(self,
                                      width=700,
                                      height=500,
                                      corner_radius=8,
                                      border_width=2,
                                      segmented_button_fg_color='gray',
                                      segmented_button_selected_color='FFEF00',
                                      segmented_button_selected_hover_color='#111',
                                      segmented_button_unselected_color='#333')

if __name__ == "__main__":
    app = App()
    app.mainloop()
